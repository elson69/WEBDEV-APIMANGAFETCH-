const container = document.getElementById('container');

fetch('https://api.mangadex.org/manga?limit=10')
  .then((res) => res.json())
  .then((data) => {
    var response = data.data[0];
    var title = response.attributes.title.en; 
    var description = response.attributes.description.en; 
    var mangaID = response.id; 
    var filename = response.relationships[2].attributes.fileName; 

    
    var imageURL = `https://uploads.mangadex.org/covers/${mangaID}/${filename}`;

    container.innerHTML = `
        <h1>${title}</h1>
        <p>${description}</p>
        <img src="${imageURL}" alt="Manga Cover">
    `;
  })
  .catch((err) => console.log(err));
console.log(response);
console.log(title);
console.log(description);
console.log(mangaID);
console.log(fileName);
